import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import ChatWindow from './components/ChatWindow';
import InputArea from './components/InputArea';
import ScrollingText from './components/ScrollingText';
import axios from 'axios';

function App() {
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const healthTips = [
    "Health Tip- Drink at least 8 glasses of water daily.",
    "Health Tip- Exercise for 30 minutes a day, 5 days a week.",
    "Health Tip- Eat a balanced diet rich in fruits and vegetables.",
    "Health Tip- Get 7-9 hours of sleep each night.",
    "Health Tip- Practice mindfulness or meditation to reduce stress."
  ];

  const handleSendMessage = async (text) => {
    setMessages(prev => [...prev, { text, sender: 'user' }]);
    setIsLoading(true);
    
    try {
      const response = await axios.post('http://localhost:5000/chat', { question: text });
      setMessages(prev => [...prev, { text: response.data.answer, sender: 'bot' }]);
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, { text: 'Sorry, there was an error processing your request.', sender: 'bot' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewChat = () => setMessages([]);

  return (
    <div className="App">
      <Sidebar onNewChat={handleNewChat} />
      <div className="main-content">
        <div className="scrolling-text-container">
          <ScrollingText tips={healthTips} />
        </div>
        <Header />
        <ChatWindow messages={messages} isLoading={isLoading} />
        <InputArea onSendMessage={handleSendMessage} isLoading={isLoading} />
      </div>
    </div>
  );
}

export default App;